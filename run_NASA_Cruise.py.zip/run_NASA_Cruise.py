''' Scripted call to single-level or multi-level (L0 - L2) command line calls to HyperCP '''
import multiprocessing
from functools import partial
import os
import glob
import time

from Main import Command
from Source.ConfigFile import ConfigFile
# Before running:
#   conda activate hypercp
# Usage:
#   python run_NASA_Cruise.py
#
# IMPORTANT NOTE: Set up the HyperCP Configuration in the GUI before running this script.
#           (Sample configurations have been provided in the HyperCP repository)
# IMPORTANT NOTE: Ancillary files should be placed in the INPUT DATA directory and named <cruise>_Ancillary.sb.
#           NOTE: Make sure symbolic links to Ancillary files are full-path, not relative.
# Cannot be run on the same machine simultaneously with alternate Configurations.
# By default processes all files in the PROC_LEVEL -1 directory to PROC_LEVEL.
#
# Block use of screen for QT if necessary
# NOTE: if you get the following error, read on...
#       "qt.qpa.plugin: Could not load the Qt platform plugin "xcb" in "" even though it was found"
#       then try first running the following in the shell:
#       export QT_QPA_PLATFORM=offscreen
################################################### CUSTOM SET UP ###################################################
# Batch options
MULTI_TASK = True     # Multiple threads for HyperSAS (any level) or TriOS (only L1A and up)
MULTI_LEVEL = False        # Process raw (L0) to Level-2 (L2)
CLOBBER = False     # True overwrites existing files
PROC_LEVEL = "L2"           # Process to this level: L1A, L1AQC, L1B, LBQC, L2 (ignored for MULTI_LEVEL)

## Dataset options
# PLATFORM = "pySAS"
# PLATFORM = "Manual_TriOS"
INST_TYPE = "SEABIRD"   # SEABIRD, TriOS, or DALEC; last two are case specific to PATH options below
CRUISE = "VIIRS2019"

# L1B_REGIME: Optional. [Default, Class, Full]
#   Denote FRM processing regime and use appropriately named subdirectories.
#   This requires a custom Configuration file (e.g., "FICE22_pySAS_Class.cfg"). Set this up in the GUI.
# L1B_REGIME = "Full"
L1B_REGIME = "" # No subdirectories for Factory/Default

# L2_VERSION: Optional. [M99NN, M99MA, M99SimSpec, Z17NN, etc.]
#   Denote a special output path for Level-2 processing alternatives.
#   I typically run this once on multilevel M99NN L0-2C, then move L1A-L1BQC and related folders back up to PATH_DATA, 
#       and run single level L2 for the rest of the options
# L2_VERSIONS = ['M99MA']
L2_VERSIONS = ["M99NN","M99SS","Z17MA","Z17NN","Z17SS"] # NOTE: Configuration file is automatically updated based on this
# STATIONS = [True]
STATIONS = [True,False]         # NOTE: Configuration file is automatically updated based on this

#################################
## PATH options
PATH_OS = os.path.expanduser('~')
PATH_HCP = f"{PATH_OS}/GitRepos/HyperCP"                # Local path to HyperCP repository.
PATH_DATA = None
if INST_TYPE.lower() == "seabird":
    PATH_DATA = f'{PATH_OS}/Projects/HyperPACE/field_data/HyperSAS/{CRUISE}'   # Top level data directory containing RAW/ and ancillary file.
elif INST_TYPE.lower() == "trios" or INST_TYPE.lower() == "dalec":
    PATH_DATA = f'{PATH_OS}/Projects/HyperPACE/field_data/{INST_TYPE}/{CRUISE}'

##################################
PATH_ANC = os.path.join(
    PATH_DATA,f'{CRUISE}_Ancillary.sb')
# PATH_ANC = '' # In case you don't have one yet

if MULTI_LEVEL or PROC_LEVEL == "L1A":
    PATH_INPUT = PATH_DATA
else:
    # Leave /RAW/ in the top level data directory
    #   Below this will be /REGIME/ L1A-L2BQC folders and
    #       /VERSION/ containing L2 folders
    PATH_INPUT = os.path.join(PATH_DATA,L1B_REGIME)

# Set these up in advance in the GUI. One config file for each REGIME, edited for each VERSION.
if L1B_REGIME == "":
    configName = f'{CRUISE}.cfg'
    PATH_CFG = os.path.join(PATH_HCP, 'Config', configName)
else:
    configName = f'{CRUISE}_{L1B_REGIME}.cfg'
    PATH_CFG = os.path.join(PATH_HCP, 'Config', configName)

# Tip: When running multiple FRM-pathways, move the RAW directory to where the input data directory needs to be.
################################################# END CUSTOM SET UP #################################################
os.environ["HYPERINSPACE_CMD"] = "TRUE"

## Setup remaining globals ##
TO_LEVELS = ["L1A", "L1AQC", "L1B", "L1BQC", "L2"]
FROM_LEVELS = ["RAW", "L1A", "L1AQC", "L1B", "L1BQC"]
FILE_EXT = None
if INST_TYPE.lower() == "seabird":
    FILE_EXT = [".raw"]                 # May need to use ".RAW" for some cruises
    # FILE_EXT = [".RAW"]                 
elif INST_TYPE.lower() == "trios":
    FILE_EXT = [".mlb"]
elif INST_TYPE.lower() == "dalec":
    FILE_EXT = [".TXT"]
FILE_EXT.extend(["_L1A.hdf", "_L1AQC.hdf", "_L1B.hdf", "_L1BQC.hdf"])

if not MULTI_LEVEL:
    iOutput = TO_LEVELS.index(PROC_LEVEL)
    TO_LEVELS = [TO_LEVELS[iOutput]]
    FROM_LEVELS = [FROM_LEVELS[iOutput]]
    FILE_EXT = [FILE_EXT[iOutput]]


def adjust_config(config, version, stations):
    ConfigFile.loadConfig(config)

    if stations:
        ConfigFile.settings["bL2Stations"] = 1
    else:
        ConfigFile.settings["bL2Stations"] = 0

    if version.startswith('M99'):
        ConfigFile.settings["bL23CRho"] = 0
        ConfigFile.settings["bL2Z17Rho"] = 0
        ConfigFile.settings["bL2M99Rho"] = 1
    elif version.startswith('Z17'):
        ConfigFile.settings["bL23CRho"] = 0
        ConfigFile.settings["bL2Z17Rho"] = 1
        ConfigFile.settings["bL2M99Rho"] = 0
    elif version.startswith('3C'):
        ConfigFile.settings["bL23CRho"] = 1
        ConfigFile.settings["bL2Z17Rho"] = 0
        ConfigFile.settings["bL2M99Rho"] = 0

    if version.endswith('MA'):
        ConfigFile.settings["bL2PerformNIRCorrection"] = 1
        ConfigFile.settings["bL2SimpleNIRCorrection"] = 1 # Mobley 1999 adapted to minimum 700-800, not 750 nm
        ConfigFile.settings["bL2SimSpecNIRCorrection"] = 0 # Ruddick 2005, Ruddick 2006 similarity spectrum
    elif version.endswith('NN'):
        ConfigFile.settings["bL2PerformNIRCorrection"] = 0
        ConfigFile.settings["bL2SimpleNIRCorrection"] = 0
        ConfigFile.settings["bL2SimSpecNIRCorrection"] = 0
    elif version.endswith('SS'):
        ConfigFile.settings["bL2PerformNIRCorrection"] = 1
        ConfigFile.settings["bL2SimpleNIRCorrection"] = 0
        ConfigFile.settings["bL2SimSpecNIRCorrection"] = 1

    ConfigFile.saveConfig(config)

def run_Command(inputFiles,outPath):
    """Run either directly or using multiprocessor pool below."""
    #   inputFiles is a string unles TriOS RAW, then list.

    # This will skip the file if either 1) the result exists and no CLOBBER, or 2) the Level failed and produced a report.
    # Override with CLOBBER, above.
    to_skip = {
        level: [
            os.path.basename(fp).split("_" + level)[0]
            for fp in glob.glob(os.path.join(outPath, level, "*"))
        ]
        + [
            os.path.basename(fp).split("_" + level)[0]
            for fp in glob.glob(os.path.join(outPath, "Reports", f"*_{level}_fail.pdf"))
        ]
        for level in TO_LEVELS
    }

    if MULTI_LEVEL:
        # One or more files. (inputFiles is a list of one or more files)
        from_level = FROM_LEVELS[0]
        to_level = 'L1A'
        final_level = 'L2'
        inputFileBase = inputFiles        # Full-path file
        test = [os.path.exists(inputFileBase[i])
                for i, x in enumerate(inputFiles)
                if os.path.exists(x)]
        if not test:
            print("***********************************")
            print(f"*** [{inputFileBase}] STOPPED PROCESSING ***")
            print(f"Bad input path: {inputFiles}")
            print("***********************************")
            return
        inputFileBase = os.path.splitext(os.path.basename(inputFiles))[0]     # 'FRM4SOC2_FICE22_NASA_20220715_120000_L1BQC'
        if INST_TYPE.lower() == 'seabird' and inputFileBase in to_skip[final_level] and not CLOBBER:
            print("************************************************")
            print(f"*** [{inputFileBase}] ALREADY PROCESSED TO {final_level} ***")
            print("************************************************")
        else:
            # NOTE: When running multi-level, it has to start over at raw, even if L1A exists.
            print("************************************************")
            print(f"*** [{inputFileBase}] PROCESSING L0 - L2 ***")
            print("************************************************")

            Command(
                PATH_CFG,
                from_level,
                inputFiles,
                outPath,
                to_level,
                PATH_ANC,
                MULTI_LEVEL)

    else:
        # One file at a time with or without multithread. (inputFiles is a string of one file)
        for from_level, to_level, _ in zip(FROM_LEVELS, TO_LEVELS, FILE_EXT):
            # inputFileBase = os.path.splitext(os.path.basename(inputFiles))[0]     # 'FRM4SOC2_FICE22_NASA_20220715_120000_L1BQC'
            inputFileBase = os.path.basename(inputFiles).split("_" + from_level)[0] # 'FRM4SOC2_FICE22_NASA_20220715_120000, 1614100, etc.
            test = os.path.exists(inputFiles)
            if not test:
                print("***********************************")
                print(f"*** [{inputFileBase}] STOPPED PROCESSING ***")
                print(f"Bad input path: {inputFiles}")
                print("***********************************")
                break
            if inputFileBase in to_skip[to_level] and not CLOBBER:
                print("************************************************")
                print(f"*** [{inputFileBase}] ALREADY PROCESSED TO {to_level} ***")
                print("************************************************")
                continue
            print("************************************************")
            print(f"*** [{inputFileBase}] PROCESSING TO {to_level} ***")
            print("************************************************")

            Command(
                PATH_CFG,
                from_level,
                inputFiles,
                outPath,
                to_level,
                PATH_ANC,
                MULTI_LEVEL
                )

def worker(fpf,pathOut):
    # fpf is a list unless multitasking, in which case it's a string, unless it's TriOS RAW
    if isinstance(fpf, list):
        if INST_TYPE.lower() == "trios" and MULTI_LEVEL:
            print(f"### Processing {fpf} ...")
            run_Command(fpf,pathOut)
        else:
            file = None
            for file in fpf:
                print(f"### Processing {os.path.basename(file)} ...")
                run_Command(file,pathOut)
            print(f"### Finished {os.path.basename(file)}")
    else:
        print(f"### Multithread Processing {os.path.basename(fpf)} ...")
        run_Command(fpf,pathOut)
        print(f"### Finished {os.path.basename(fpf)}")

if __name__ == '__main__':
    t0Single = time.time()
    for STATION in STATIONS:
        for L2_VERSION in L2_VERSIONS:
            # PATH_OUTPUT does not require folder names of data levels. HyperCP will automate that.
            if PROC_LEVEL == 'L2':
                PATH_OUTPUT = os.path.join(PATH_DATA,L1B_REGIME,L2_VERSION)
            else:    
                PATH_OUTPUT = os.path.join(PATH_DATA,L1B_REGIME)
            if os.path.isdir(PATH_OUTPUT) is False:
                os.mkdir(PATH_OUTPUT)

            # Adjust the configuration file to reflect the L2 variant and whether stations are being run.
            adjust_config(configName, L2_VERSION,STATION)

            t1Single = time.time()

            # Input list of one or more elements:
            fp_input_files = sorted(
                glob.glob(os.path.join(PATH_INPUT, FROM_LEVELS[0], f"*{FILE_EXT[0]}")))

            # # NOTE: For debugging VVV
            # fp_input_files = [fp_input_files[0]]

            partial_worker = partial(worker,pathOut=PATH_OUTPUT)

            if fp_input_files:
                print(f"Processing {fp_input_files}")
                print(f"Using configuration {PATH_CFG}")
                print(f"with ancillary data {PATH_ANC}")

                if MULTI_TASK:
                    # If Z17 correction is enabled in L2, a significant amount of
                    #   memory is used (~3GB) for each process so you may not be able to
                    #   use all cores of the system without problems.
                    with multiprocessing.Pool(4) as pool:
                        # One file (string) at a time to worker
                        pool.map(
                            partial_worker, fp_input_files
                        )
                else:
                    # List of one or more files
                    worker(fp_input_files,PATH_OUTPUT)

                t2Single = time.time()
                print(f"Overall time elapsed: {str(round((t2Single-t1Single)/60))} minutes")

            else:
                print(f"No input files found {os.path.join(PATH_INPUT, FROM_LEVELS[0], FILE_EXT[0])}")
        t3Single = time.time()

        mesg = f"Global batch time elapsed: {str(round((t2Single-t1Single)/60))} minutes"
        print(mesg)
        if STATION:
            with open(PATH_OUTPUT + 'batchlog_stations.txt', 'w', encoding="utf-8") as logFile:
                logFile.write(mesg + "\n")
        else:
            with open(PATH_OUTPUT + 'batchlog_no_stations.txt', 'w', encoding="utf-8") as logFile:
                logFile.write(mesg + "\n")
    
